## HTML
Linguagem de marcação de texto

## Hypertext
Hipertexto -> link / sons / imagens / videos

## Markup
Marcação -> tag

## Language
Linguagem -> estrutura semantica / sintaxe

